#include "ListArr.h"
#include <iostream>
using namespace std;

int main(){
	ListArr* array = new ListArr(2, 5);
	//for(int i = 0; i < 10; ++i) array->insert(i + 1, i);
	//array->print();
	return 0;
}